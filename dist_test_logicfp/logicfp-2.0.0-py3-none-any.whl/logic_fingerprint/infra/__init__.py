"""Infrastructure adapters and integrations."""
